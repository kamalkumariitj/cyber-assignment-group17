# Buffer Overflow Attack (Server) — Demo

**Assignment 1 — Software Security**
Educational demonstration of a classic stack-based buffer overflow against
a vulnerable TCP server, plus a discussion of defences.

> ⚠️ **For educational use only.** Run every step inside an isolated VM
> (we used Ubuntu 20.04 32-bit / SEED Labs VM). Do not run, deploy, or
> point this code at any machine you do not personally own. The authors
> accept no liability for misuse.

---

## 1. Files

| File          | Purpose                                                |
| ------------- | ------------------------------------------------------ |
| `server.c`    | Vulnerable TCP server. Uses `memcpy` with no bounds check. |
| `exploit.py`  | Builds a NOP-sled + shellcode + return-address payload and sends it. |
| `Makefile`    | Builds vulnerable and hardened versions.               |
| `README.md`   | This file.                                             |

---

## 2. Environment

- Ubuntu 20.04 / 22.04 (or the SEED Labs Ubuntu VM)
- `gcc-multilib` (for 32-bit builds): `sudo apt install gcc-multilib`
- Python 3.6 or newer
- `gdb` (optional, for stepping through the overflow)

---

## 3. Disable runtime protections (inside the VM)

```bash
# Turn OFF address-space layout randomization for a predictable stack address
sudo sysctl -w kernel.randomize_va_space=0
```

The compile-time protections (stack canaries, NX, PIE) are already disabled
by the Makefile flags. We re-enable them when building `server_secure` to
show that the same exploit then fails.

---

## 4. Build

```bash
make                # builds the vulnerable ./server
make secure         # builds the hardened ./server_secure (for comparison)
```

---

## 5. Run the demo

### Terminal A — start the vulnerable server

```bash
./server
# [server] buffer address hint: 0xffffd1a0
# [server] listening on port 9090 ...
```

Copy the printed buffer address — you will use it (or a nearby address
inside the NOP sled) as the new return address.

### Terminal B — fire the exploit

```bash
# Use a return address that points inside the NOP sled
# (a bit higher than the buffer address — e.g. buffer_addr + 0x60)
python3 exploit.py 0xffffd200
```

Expected behaviour: the server's process flow returns into the NOP sled,
slides into the shellcode, executes `execve("/bin/sh", 0, 0)`, and you get
an interactive shell on Terminal A's TTY.

### Verify the shell

```sh
$ id
uid=1000(seed) gid=1000(seed) ...
```

---

## 6. Confirm that hardening blocks the attack

```bash
./server_secure        # in Terminal A
python3 exploit.py 0xffffd200   # in Terminal B
```

You should now see one of:
- `*** stack smashing detected ***: terminated`  (canary tripped)
- Segmentation fault                              (NX prevents executing shellcode on the stack)
- A different address each run                    (PIE + ASLR re-enabled)

This contrast is the point of the demonstration: the vulnerability in the
source code is the same, but the binary's defences turn the exploit into a
crash instead of a remote shell.

---

## 7. Countermeasures discussed in the presentation

1. **Safe APIs** — replace `strcpy`/`memcpy` with `strncpy`/`memcpy_s` or
   length-checked alternatives; better still, use languages that bound
   memory accesses by default (Rust, Go).
2. **Stack canaries** — `-fstack-protector-strong` adds a guard value that
   the function checks before returning.
3. **Non-executable stack (NX/DEP)** — marks the stack non-executable so
   injected shellcode cannot run.
4. **ASLR** — randomises stack, heap, library, and code addresses, making
   it hard to guess where to jump.
5. **PIE** — randomises the executable's own code as well.
6. **Fortify Source** — `-D_FORTIFY_SOURCE=2` adds compile-time length
   checks to common libc functions.
7. **Code review and fuzz testing** — catch unbounded copies before they
   reach production.

Attackers respond with ROP, info-leak primitives, and heap-grooming, so
defences must be layered.

---

## 8. Demo video

The recording is in the parent zip: `demo.mp4` (or the link in the slides).

---

## 9. Team

See the *Team Member Contributions* slide in the presentation.
